# [unity] ISO-2  타일맵 깔기(장애물편)

---

<aside>
💡 **HEADER**

</aside>

---

# 개요

---

유니티 환경에서 ISO 뷰의 세팅을 해보자

<aside>
⚠️ 작성시기 2023년 02월

</aside>

<aside>
⚠️ unity 2021.3.1f1 에서 진행되었습니다.

</aside>


# 장애물(벽) 을 만들어보자

---

![Untitled](/%5Bunity%5D%20ISO-2%20%ED%83%80%EC%9D%BC%EB%A7%B5%20%EA%B9%94%EA%B8%B0(%EC%9E%A5%EC%95%A0%EB%AC%BC%ED%8E%B8)%205691cb5791494cae900d10b2ab7cc1dd/Untitled.png)

지난 기사에서 이렇게 베이스 바닥을 만들어내는데에 성공했다. 

이제 벽을 만들어 보자.

이전과 동일한 방식으로 돌 타일을 생성했다.

![Untitled](/%5Bunity%5D%20ISO-2%20%ED%83%80%EC%9D%BC%EB%A7%B5%20%EA%B9%94%EA%B8%B0(%EC%9E%A5%EC%95%A0%EB%AC%BC%ED%8E%B8)%205691cb5791494cae900d10b2ab7cc1dd/Untitled%201.png)

벽같은 경우 기존 있는 타일보다 위에 얹어져야 하기 때문에 조금 다른 설정이 필요하다.

![Untitled](/%5Bunity%5D%20ISO-2%20%ED%83%80%EC%9D%BC%EB%A7%B5%20%EA%B9%94%EA%B8%B0(%EC%9E%A5%EC%95%A0%EB%AC%BC%ED%8E%B8)%205691cb5791494cae900d10b2ab7cc1dd/Untitled%202.png)

일단은 벽 전용 타일맵을 새로생성 ( * 이후 할 콜라이더 작업, 그림자 작업을 위해서 필수)

![Untitled](/%5Bunity%5D%20ISO-2%20%ED%83%80%EC%9D%BC%EB%A7%B5%20%EA%B9%94%EA%B8%B0(%EC%9E%A5%EC%95%A0%EB%AC%BC%ED%8E%B8)%205691cb5791494cae900d10b2ab7cc1dd/Untitled%203.png)

브러쉬 설정의 Zpos lock을 해제한 후 z pos를 2로 변경

> 일반적 블록 사이즈라면 2가 1칸어치 크기임
> 

![Untitled](/%5Bunity%5D%20ISO-2%20%ED%83%80%EC%9D%BC%EB%A7%B5%20%EA%B9%94%EA%B8%B0(%EC%9E%A5%EC%95%A0%EB%AC%BC%ED%8E%B8)%205691cb5791494cae900d10b2ab7cc1dd/Untitled%204.png)

그대로 그려내면 완성

# 콜라이더를 입혀보자

---

방금 설치했던 Wall 타일맵에 tilemap collider 컴포넌트를 추가

![Untitled](/%5Bunity%5D%20ISO-2%20%ED%83%80%EC%9D%BC%EB%A7%B5%20%EA%B9%94%EA%B8%B0(%EC%9E%A5%EC%95%A0%EB%AC%BC%ED%8E%B8)%205691cb5791494cae900d10b2ab7cc1dd/Untitled%205.png)


![Untitled](/%5Bunity%5D%20ISO-2%20%ED%83%80%EC%9D%BC%EB%A7%B5%20%EA%B9%94%EA%B8%B0(%EC%9E%A5%EC%95%A0%EB%AC%BC%ED%8E%B8)%205691cb5791494cae900d10b2ab7cc1dd/Untitled%206.png)

콜라이더가 입혀진건 좋지만 뭔가 콜라이더가 엉성하게 생겼다.


벽 타일에 사용된 이미지의 sprite Editor 를 들어가보면 해답이 나온다.

![Untitled](/%5Bunity%5D%20ISO-2%20%ED%83%80%EC%9D%BC%EB%A7%B5%20%EA%B9%94%EA%B8%B0(%EC%9E%A5%EC%95%A0%EB%AC%BC%ED%8E%B8)%205691cb5791494cae900d10b2ab7cc1dd/Untitled%207.png)

### SpriteEditor 옵션에서 CustomPhysicsShape를 클릭

![Untitled](/%5Bunity%5D%20ISO-2%20%ED%83%80%EC%9D%BC%EB%A7%B5%20%EA%B9%94%EA%B8%B0(%EC%9E%A5%EC%95%A0%EB%AC%BC%ED%8E%B8)%205691cb5791494cae900d10b2ab7cc1dd/Untitled%208.png)

드래그를 활용해서 원하는 콜라이더의 모양을 만든다.

![Untitled](/%5Bunity%5D%20ISO-2%20%ED%83%80%EC%9D%BC%EB%A7%B5%20%EA%B9%94%EA%B8%B0(%EC%9E%A5%EC%95%A0%EB%AC%BC%ED%8E%B8)%205691cb5791494cae900d10b2ab7cc1dd/Untitled%209.png)

<aside>
⚠️ 콜라이더를 절반만 만든 이유는 뒤쪽으로 캐릭터가 다니게 할 수 있게 하기 위함. 
필요에 따라서 블로 전체를 싸도 상관없음

</aside>

<aside>
⚠️ apply 한후 타일을 다시 그려줘야한다!!! 기존에 그려진 타일은 적용되지않는다

</aside>

![Untitled](/%5Bunity%5D%20ISO-2%20%ED%83%80%EC%9D%BC%EB%A7%B5%20%EA%B9%94%EA%B8%B0(%EC%9E%A5%EC%95%A0%EB%AC%BC%ED%8E%B8)%205691cb5791494cae900d10b2ab7cc1dd/Untitled%2010.png)

얼추 예쁘게 모양이 나왔다.

### 굳이 콜라이더가 여러개 있어야할까?

composite collider 를 도입해서 더욱 깔끔한 콜라이더를 제작

![Untitled](/%5Bunity%5D%20ISO-2%20%ED%83%80%EC%9D%BC%EB%A7%B5%20%EA%B9%94%EA%B8%B0(%EC%9E%A5%EC%95%A0%EB%AC%BC%ED%8E%B8)%205691cb5791494cae900d10b2ab7cc1dd/Untitled%2011.png)

<aside>
⚠️ 주의!  rigidbody의 설정을 static으로 바꿔주고 기존 타일맵 콜라이더 설정에서 used by composite 설정을 활성화시켜주지 않으면 오류가 발생할 수 있다.

</aside>

![Untitled](/%5Bunity%5D%20ISO-2%20%ED%83%80%EC%9D%BC%EB%A7%B5%20%EA%B9%94%EA%B8%B0(%EC%9E%A5%EC%95%A0%EB%AC%BC%ED%8E%B8)%205691cb5791494cae900d10b2ab7cc1dd/Untitled%2012.png)

# 결과

---

![Untitled](/%5Bunity%5D%20ISO-2%20%ED%83%80%EC%9D%BC%EB%A7%B5%20%EA%B9%94%EA%B8%B0(%EC%9E%A5%EC%95%A0%EB%AC%BC%ED%8E%B8)%205691cb5791494cae900d10b2ab7cc1dd/Untitled%2013.png)

 꽤나 깔끔하게 벽이 완성되었다!