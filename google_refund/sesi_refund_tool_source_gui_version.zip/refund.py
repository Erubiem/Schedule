from googleapiclient.errors import HttpError
from googleapiclient.discovery import build


def call_refund_api( package_name:str,order_id:str,creds):

    # API 클라이언트 생성
    service = build('androidpublisher', 'v3', credentials=creds,static_discovery=False)

    # 환불 처리
    try:
        refund_request = service.orders().refund(
            packageName=package_name,
            orderId = order_id
        ).execute()
        

        print(f'주문 ID {order_id} 환불이 처리되었습니다.')
    except HttpError as error:
        print(f'주문 ID {order_id} 환불 처리 중 오류가 발생했습니다: {error}')
