import os
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow

class Auth_class:

    projectPath:str
    CLIENT_SECRETS_FILE = 'auth/client_secrets.json'
    CREDENTIALS_JSON_FILE = 'auth/credentials.json'

    def __init__(self,projectPath):
        self.projectPath = projectPath

# 인증정보 불러오기. 
# 엑세스 토큰이 만료된 경우에는 로드과정에서 자동으로 갱신 후 재발급한다.
# 단, credentials.json 에서 필요한 값이 있어야 한다.
    def load_credentials(self,_scopes:list[str]):
        file_path = f'{self.projectPath}/{self.CREDENTIALS_JSON_FILE}'

        if os.path.isfile(file_path):
            credentials = Credentials.from_authorized_user_file(file_path,scopes = _scopes)
            if credentials.valid:
                return credentials

        #if credentials.expired and credentials.refresh_token:
        return self.call_flow(_scopes)

#인증 창 띄우기
    def call_flow(self,_scopes:list[str]):
        flow = InstalledAppFlow.from_client_secrets_file(f'{self.projectPath}/{self.CLIENT_SECRETS_FILE}', _scopes)
        creds = flow.run_local_server(port=0)
        self.save_credentials_json(creds)
        return creds

# 토큰 저장
    def save_credentials_json(self,credentials:Credentials):
        with open(f'{self.projectPath}/{self.CREDENTIALS_JSON_FILE}', 'w') as f:
            f.write(credentials.to_json())

"""참고사항.

A> google oauth2에서 발급받은 리프레쉬 토큰은 다음 경우에 만료된다.

    - 사용자가 앱의 액세스를 취소했습니다.
    - 갱신 토큰이 6개월 동안 사용되지 않았습니다.
    - 사용자가 비밀번호를 변경했으며 갱신 토큰에 Gmail 범위가 포함되어 있습니다.
    - 사용자 계정이 부여된 최대 갱신 토큰 수를 초과했습니다.
    - 관리자가 앱 범위에서 요청된 서비스를 '제한됨'(오류: admin_policy_enforced)으로 설정한 경우
    - Google Cloud Platform API의 경우 관리자가 설정한 세션 시간이 초과되었을 수 있습니다.

B > 서비스 계정은 도메인별 허용범위를 설정해줘야 사용가능한 듯 하다. 일반적인 방법으로는 oauth2 인증이 필요한 api 를 사용못하는 것으로 보임. (androidpublisher)
    - 도메인별 허용범위를 위해선 구글 워크 스페이스 계정이 필요하다.

C > oauth2 기능을 사용하는 api이지만, 구글 클라우드 콘솔에서 플레이 콘솔 연결 또한 필요하다.

D > 별도의 웹페이지를 구성하지 않고 oauth2 토큰을 발급받고 싶다면, flow 혹은 https://developers.google.com/oauthplayground를 사용하는 것을 추천한다.
        - https://developers.google.com/oauthplayground 사용 시 
            1. api 문서를 참조해 도메인 스코프를 검색하여 체크하고, 
            2. 오른쪽 상단 설정버튼을 누른뒤 Use your own Oauth credentials 를 체크.
            3. oauth client ID, secret 를 입력 후 
            4. authorize apis 버튼 클릭.
            5. step2 로 자동 전환 대기
            6. Exchange authorization code for tokens 클릭
            7. 발급 받은 토큰을 저장하여 사용.

"""