import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
from auth import Auth_class
import configparser
from refund import call_refund_api


PROJECT_PATH = dir_path = os.path.dirname(os.path.realpath(__file__))

def main(args):

    auth = Auth_class(PROJECT_PATH)




    data = {
        'order_ids' : args.order_ids,
        'package_name':args.package_name,
        'creds':auth.load_credentials(['https://www.googleapis.com/auth/androidpublisher'])
    }

    thread_refund_api(call_refund_api, data)


def thread_refund_api(func, data):
    

    order_ids = data['order_ids'].split(',')

    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = [executor.submit(func, package_name=data['package_name'], order_id=order_id.strip(),creds=data['creds']) for order_id in order_ids]

    for future in as_completed(futures):
        if future.exception() is not None:
            print(f'주문 ID {future.result()} 처리 중 오류가 발생했습니다: {future.exception()}')




if __name__ == "__main__":

    config = configparser.ConfigParser()
    config.read(f'{PROJECT_PATH}/config.ini')
    # argparser를 이용하여 인자값 받기
    parser = argparse.ArgumentParser(description="""
구매 시 발급된 토큰값을 참조하여 해당 상품을 환불하는 프로그램입니다.

패키지명을 입력하지않으면, 기본 패키지를 참조합니다.(천상비)

sku id 를 입력하지 않으면 sku id를 자동으로 검색하여 실행합니다.
    - 단, sku id를 입력하지 않은 상태에서 같은 경로 내 Sesi_sku_id_search.py 가 없을 경우 오류가 발생합니다.


* 주의사항
    프로젝트의 폴더 내에 구글 계정 인증 정보(credentials.json)가 있어야 합니다.
    사용에 유의 바랍니다.
    """, formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument('-p', '--package_name', type=str, default=config.get('default','pakage_name'), help='패키지 명 입력. ex> com.sesisoft.xxx')
    parser.add_argument('order_ids', type=str, help='사용자에게 제공되는 주문 ID (쉼표로 구분된 문자열)')
    args = parser.parse_args()

    main(args)

  