import argparse
import subprocess
import json
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton,QTextEdit
import sys
import configparser

#from lib.refund_tool import main


PROJECT_PATH = dir_path = './lib' #os.path.dirname(os.path.realpath(__file__))
class App(QWidget):
    def __init__(self):
        super().__init__()

        # config.ini 파일 읽기
        config = configparser.ConfigParser()
        config.read(f'{PROJECT_PATH}/config.ini')

        # 창 타이틀 설정
        self.title = '환불 프로그램'

        # 창 크기 설정
        self.left = 300
        self.top = 300
        self.width = 640
        self.height = 480

        # 연결된 프로젝트 정보
        self.project_id_label = QLabel('project_id:', self)
        self.project_id_label.move(50, 50)


        self.project_id_val_label = QLabel(load_project_name(),self)
        self.project_id_val_label.move(150, 50)
        

        # 패키지명 입력 필드 생성
        self.package_name_label = QLabel('패키지 명:', self)
        self.package_name_label.move(50, 100)
        self.package_name_input = QLineEdit(self)
        self.package_name_input.move(150, 100)
        self.package_name_input.setText(config.get('default', 'pakage_name'))

        # 주문 ID 입력 필드 생성
        self.order_ids_label = QLabel('Order IDs:', self)
        self.order_ids_label.move(50, 150)
        self.order_ids_input = QTextEdit(self)
        self.order_ids_input.move(150, 150)
        self.order_ids_input.setFixedSize(380, 280)
       # self.order_ids_input.setWordWrapMode(QTextOption.WrapMode.WordWrap)

        # 확인 버튼 생성
        self.button = QPushButton('Confirm', self)
        self.button.move(430, 450)

        # 버튼 클릭 시 실행할 함수 지정
        self.button.clicked.connect(self.on_click)

        # 창 띄우기
        self.initUI()

    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
        self.show()

    def on_click(self):
        # 사용자가 입력한 패키지명, 주문 ID 가져오기
        package_name = self.package_name_input.text()
        order_ids:str = self.order_ids_input.toPlainText()

        order_id_list:list = [order_id.strip() for order_id in order_ids.split('\n') if not order_id.isspace() and bool(order_id)]
        order_ids = ','.join(order_id_list)

        print(order_ids)

        # 인자값 설정
        #args = argparse.Namespace(package_name=package_name, order_ids=order_ids)

        # main 함수 실행
        subprocess.run([f'{PROJECT_PATH}/refund_tool.exe', '-p',package_name,order_ids])

        #main(args)
        


def load_project_name():
    with open(f'{PROJECT_PATH}/auth/client_secrets.json', 'r') as f:
        data = json.load(f)

    return data['installed']['project_id']

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = App()
    sys.exit(app.exec_())
