python version : 3.10.2



초기설정
-------------
1. venv 가상환경 설정 후 가상환경에서 실행
2. pip install -r requirements.txt


신규 라이브러리 추가 시
-------------
pip freeze > requirements.txt


빌드 시 (venv 환경에서 실행)
-------------
	pyinstaller --add-data "./auth/;auth" --add-data "config.ini;." refund_tool.py
	rename dist\refund_tool lib
	pyinstaller --onefile refund_tool_windows.py
	


실행파일 초기설정
-------------
lib\auth  내 oauth2 client_secrets.json 파일 삽입
lib\config.ini 의 디폴트 값 수정(선택사항)


